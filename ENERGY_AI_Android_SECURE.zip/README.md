# ENERGY AI Android — conexión segura

Esta versión conecta la PWA a OpenAI mediante un servidor Node.js. La clave API **no** está en `public/index.html` ni en el ZIP.

## Publicar en Render
1. Sube el contenido de esta carpeta a un repositorio privado de GitHub.
2. En Render crea un **New Web Service** y conecta ese repositorio.
3. Render detectará `render.yaml`; usa `npm install` y `npm start`.
4. En Render → servicio → **Environment**, añade `OPENAI_API_KEY` con una clave NUEVA. No reutilices la clave que compartiste en el chat: revócala primero en https://platform.openai.com/api-keys.
5. Guarda y espera el redeploy. Abre la URL HTTPS de Render para usar ENERGY AI.

## Prueba local (opcional)
- Instala Node.js 20 o superior.
- Ejecuta `npm install`.
- Configura `OPENAI_API_KEY` como variable de entorno (o copia `.env.example` a `.env` e instala/usa un cargador de variables si lo configuras).
- Ejecuta `npm start` y abre http://localhost:3000.

**Seguridad:** nunca pongas la clave en HTML/JavaScript del navegador, ni la subas a GitHub, ni la compartas en chats. Establece límites de gasto en OpenAI Platform y vigila el uso.

La integración de análisis del archivo `bass_audio1.energy` no está incluida todavía; esta actualización conecta el chat con OpenAI.
