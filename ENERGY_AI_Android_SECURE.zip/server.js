import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Escribe un mensaje." });
    if (message.length > 8000) return res.status(413).json({ error: "El mensaje es demasiado largo." });
    if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: "El servidor todavía no tiene OPENAI_API_KEY configurada." });
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const result = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5-mini",
      instructions: "Eres ENERGY AI, un asistente útil, claro y amable. Responde en español salvo que el usuario pida otro idioma.",
      input: message
    });
    res.json({ reply: result.output_text || "No se generó una respuesta." });
  } catch (error) {
    console.error("ENERGY AI API error:", error?.message || error);
    res.status(500).json({ error: "Error al consultar el servicio de IA. Revisa la configuración del servidor." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ENERGY AI listening on ${port}`));
